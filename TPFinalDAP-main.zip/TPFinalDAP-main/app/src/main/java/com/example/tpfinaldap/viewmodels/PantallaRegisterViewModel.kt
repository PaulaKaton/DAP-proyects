package com.example.tpfinaldap.viewmodels

import androidx.lifecycle.ViewModel

class PantallaRegisterViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}