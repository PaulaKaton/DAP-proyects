package com.example.tpfinaldap.viewmodels

import androidx.lifecycle.ViewModel

class SubirSuperHeroViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}