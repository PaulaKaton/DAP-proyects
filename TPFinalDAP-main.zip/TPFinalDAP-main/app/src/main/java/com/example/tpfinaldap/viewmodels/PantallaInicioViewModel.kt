package com.example.tpfinaldap.viewmodels

import androidx.lifecycle.ViewModel

class PantallaInicioViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}