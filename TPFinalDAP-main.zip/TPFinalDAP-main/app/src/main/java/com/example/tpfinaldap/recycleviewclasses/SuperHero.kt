package com.example.tpfinaldap.recycleviewclasses

data class SuperHero (
    var superhero:String? = null ,
    var realName:String? = null ,
    var publisher:String? = null,
    var photo:String? = null,
    var description:String? = null,
    var idSuperHero:String? = null,
)