package com.example.trabajoprcticodaplogin_recyclerview.entities

class Users (
    val username : String,
    val password : String
)