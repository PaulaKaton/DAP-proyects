package com.example.trabajoprcticodaplogin_recyclerview.entities

data class Pokemon(
    var pokeNum: String,
    var pokeName: String,
    var pokeType1: String,
    var pokeType2: String,
    var pokeWeight: String,
    var pokeHeight: String,
)