package com.example.trabajoprcticodaplogin_recyclerview.viewmodels

import androidx.lifecycle.ViewModel

class FragmentMoreOptionsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}