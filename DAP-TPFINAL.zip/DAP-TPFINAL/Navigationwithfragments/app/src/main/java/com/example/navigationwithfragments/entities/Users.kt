package com.example.navigationwithfragments.entities

class Users (
        var user : String,
        var pass: String
)