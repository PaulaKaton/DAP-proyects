package com.ort.movieapp.entities

class Movie (
    var title : String,
    var description : String,
    var urlImage : String
        ) {
}