package com.ort.movieapp.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.ort.movieapp.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}